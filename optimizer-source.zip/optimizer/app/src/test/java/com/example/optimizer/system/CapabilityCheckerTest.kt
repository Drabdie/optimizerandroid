package com.example.optimizer.system

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Главное свойство, которое обязано выполняться: без root/ADB
 * приложение НИКОГДА не должно сообщать available = true.
 * Это прямое требование безопасности из спецификации.
 */
class CapabilityCheckerTest {

    private val checker = CapabilityChecker()

    @Test
    fun `animation scale change is honestly reported as unavailable`() {
        val result = checker.check(Capability.ANIMATION_SCALE_CHANGE)
        assertFalse(result.available)
        assertTrue(result.reason.isNotBlank())
    }

    @Test
    fun `refresh rate override is honestly reported as unavailable`() {
        val result = checker.check(Capability.REFRESH_RATE_OVERRIDE)
        assertFalse(result.available)
        assertTrue(result.reason.isNotBlank())
    }

    @Test
    fun `cpu governor change without root is reported as unavailable`() {
        // В тестовом окружении (и у подавляющего большинства пользователей) root отсутствует,
        // поэтому ожидаем честный отказ, а не фиктивный успех.
        val result = checker.check(Capability.CPU_GOVERNOR_CHANGE)
        assertFalse(result.available)
    }

    @Test
    fun `every capability returns a non-empty explanation`() {
        Capability.entries.forEach { capability ->
            val result = checker.check(capability)
            assertTrue(
                "Capability $capability вернул пустое объяснение",
                result.reason.isNotBlank()
            )
        }
    }
}
