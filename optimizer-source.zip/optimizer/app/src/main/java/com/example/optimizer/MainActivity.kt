package com.example.optimizer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.optimizer.ui.dashboard.DashboardScreen
import com.example.optimizer.ui.modes.PerformanceModesScreen
import com.example.optimizer.ui.theme.OptimizerTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            OptimizerTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    OptimizerApp()
                }
            }
        }
    }
}

private enum class AppTab(val label: String, val emoji: String) {
    Dashboard("Обзор", "\uD83D\uDCCA"),
    Modes("Режимы", "\u2699")
}

@Composable
private fun OptimizerApp() {
    // Намеренно remember, а не rememberSaveable: вкладка — второстепенное UI-состояние,
    // терять его при повороте экрана не критично, а Saver для enum добавлял бы лишний риск.
    var tab by remember { mutableStateOf(AppTab.Dashboard) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(if (tab == AppTab.Dashboard) "Optimizer" else "Режимы производительности") })
        },
        bottomBar = {
            NavigationBar {
                AppTab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Text(t.emoji, style = MaterialTheme.typography.titleMedium) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                AppTab.Dashboard -> DashboardScreen()
                AppTab.Modes -> PerformanceModesScreen()
            }
        }
    }
}
