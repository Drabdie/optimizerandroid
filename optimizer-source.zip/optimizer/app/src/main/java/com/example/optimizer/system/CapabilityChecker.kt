package com.example.optimizer.system

import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

enum class Capability {
    CPU_GOVERNOR_CHANGE,   // требует root
    ANIMATION_SCALE_CHANGE, // требует WRITE_SECURE_SETTINGS (ADB) или системные настройки
    REFRESH_RATE_OVERRIDE  // частично доступно через системные Intent, иначе ADB/root
}

data class CapabilityResult(
    val available: Boolean,
    val reason: String
)

/**
 * Единственное место, где честно решается: можно ли реально выполнить действие,
 * или нужно сказать пользователю правду про root/ADB.
 * Никогда не возвращает "available = true" без реальной проверки.
 */
@Singleton
class CapabilityChecker @Inject constructor() {

    fun check(capability: Capability): CapabilityResult = when (capability) {
        Capability.CPU_GOVERNOR_CHANGE -> {
            if (hasRoot()) {
                CapabilityResult(true, "Root обнаружен, но изменение governor всё равно рискованно.")
            } else {
                CapabilityResult(
                    false,
                    "Эта функция недоступна без root — Android не позволяет обычным приложениям менять CPU governor."
                )
            }
        }
        Capability.ANIMATION_SCALE_CHANGE -> CapabilityResult(
            false,
            "Требуется разрешение WRITE_SECURE_SETTINGS, выдаваемое только через ADB, либо ручная настройка пользователем в Настройки → Для разработчиков."
        )
        Capability.REFRESH_RATE_OVERRIDE -> CapabilityResult(
            false,
            "Прямое переключение частоты обновления зависит от производителя. Мы можем открыть системные настройки дисплея, но не изменить значение напрямую без root."
        )
    }

    private fun hasRoot(): Boolean {
        val paths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/system/su", "/vendor/bin/su"
        )
        return paths.any { File(it).exists() }
    }
}
