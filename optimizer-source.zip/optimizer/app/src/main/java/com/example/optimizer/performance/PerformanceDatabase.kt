package com.example.optimizer.performance

import androidx.room.*
import kotlinx.coroutines.flow.Flow

enum class PerformanceMode { BALANCED, PERFORMANCE, GAMING, BATTERY_SAVER }

@Entity(tableName = "performance_state")
data class PerformanceState(
    @PrimaryKey val id: Int = 0,
    val activeMode: PerformanceMode
)

@Dao
interface PerformanceModeDao {
    @Query("SELECT * FROM performance_state WHERE id = 0")
    fun observeState(): Flow<PerformanceState?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setState(state: PerformanceState)
}

@Database(entities = [PerformanceState::class], version = 1)
abstract class PerformanceDatabase : RoomDatabase() {
    abstract fun performanceModeDao(): PerformanceModeDao
}
