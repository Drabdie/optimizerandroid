package com.example.optimizer.data

/**
 * Снимок реальных, измеримых показателей устройства.
 * Любое поле, которое ОС не отдаёт напрямую, помечается как null,
 * а не заменяется выдуманным значением.
 */
data class DeviceSnapshot(
    val deviceModel: String,
    val manufacturer: String,
    val androidVersion: String,
    val apiLevel: Int,

    val cpuCoreCount: Int,
    val cpuAbi: String,

    val ramTotalMb: Long?,
    val ramAvailableMb: Long?,
    val ramLowMemory: Boolean?,

    val storageFreeGb: Double,
    val storageTotalGb: Double,

    // null если система/производитель не предоставляют доступ
    val batteryTemperatureC: Float?,
    val batteryLevelPercent: Int?,
    val isCharging: Boolean?,

    val screenRefreshRateHz: Float?,
    val screenResolution: String,
    val screenDensityDpi: Int,

    val thermalStatus: String? // требует API 29+, может быть недоступен на части устройств
)
