package com.example.optimizer.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.StatFs
import androidx.annotation.RequiresApi
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Единственный источник правды по данным устройства.
 * Все значения читаются через официальные Android API.
 * Ничего не подделывается — если ОС не даёт значение, поле = null.
 */
@Singleton
class DeviceInfoProvider @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun snapshot(): DeviceSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }

        val statFs = StatFs(context.filesDir.path)
        val storageFreeGb = statFs.availableBytes / 1_000_000_000.0
        val storageTotalGb = statFs.totalBytes / 1_000_000_000.0

        val battery = readBatteryInfo()
        val display = readDisplayInfo()

        return DeviceSnapshot(
            deviceModel = Build.MODEL,
            manufacturer = Build.MANUFACTURER,
            androidVersion = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT,

            cpuCoreCount = Runtime.getRuntime().availableProcessors(),
            cpuAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",

            ramTotalMb = memInfo.totalMem / (1024 * 1024),
            ramAvailableMb = memInfo.availMem / (1024 * 1024),
            ramLowMemory = memInfo.lowMemory,

            storageFreeGb = storageFreeGb,
            storageTotalGb = storageTotalGb,

            batteryTemperatureC = battery.first,
            batteryLevelPercent = battery.second,
            isCharging = battery.third,

            screenRefreshRateHz = display.first,
            screenResolution = display.second,
            screenDensityDpi = display.third,

            thermalStatus = readThermalStatus()
        )
    }

    /** Возвращает Triple(температура, уровень заряда %, заряжается ли) */
    private fun readBatteryInfo(): Triple<Float?, Int?, Boolean?> {
        val intent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ) ?: return Triple(null, null, null)

        val tempTenthsCelsius = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temperature = if (tempTenthsCelsius == Int.MIN_VALUE) null else tempTenthsCelsius / 10f

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val levelPercent = if (level >= 0 && scale > 0) (level * 100 / scale) else null

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        return Triple(temperature, levelPercent, charging)
    }

    /** Возвращает Triple(частота обновления Hz, "widthxheight", dpi) */
    private fun readDisplayInfo(): Triple<Float?, String, Int> {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(android.view.Display.DEFAULT_DISPLAY)
        val metrics = context.resources.displayMetrics
        val resolution = "${metrics.widthPixels}x${metrics.heightPixels}"
        val refreshRate = display?.refreshRate
        return Triple(refreshRate, resolution, metrics.densityDpi)
    }

    private fun readThermalStatus(): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return null
        return thermalStatusToLabel(pm.currentThermalStatus)
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun thermalStatusToLabel(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "Нормальная"
        PowerManager.THERMAL_STATUS_LIGHT -> "Лёгкий перегрев"
        PowerManager.THERMAL_STATUS_MODERATE -> "Умеренный перегрев"
        PowerManager.THERMAL_STATUS_SEVERE -> "Сильный перегрев"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Критический"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Аварийный"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Выключение по перегреву"
        else -> "Неизвестно"
    }
}
