package com.example.optimizer

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class OptimizerApp : Application()
