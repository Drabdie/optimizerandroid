# Optimizer

Android-приложение для отображения реальных показателей устройства и честного управления доступными режимами производительности.

## Требования

- Android Studio (актуальная стабильная версия)
- JDK 17 или новее
- Android SDK Platform 35
- Android SDK Build-Tools 35.x

Проект использует Android Gradle Plugin 8.5.2 и Gradle 8.7.

## Сборка

### Linux / macOS

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

### Windows

```bat
gradlew.bat testDebugUnitTest
gradlew.bat assembleDebug
```

При первом запуске `gradlew` автоматически скачает Gradle 8.7 в пользовательский Gradle-кэш. Поэтому интернет нужен только для первоначальной загрузки Gradle и зависимостей.

APK после успешной сборки:

`app/build/outputs/apk/debug/app-debug.apk`

## Проверка перед релизом

```bash
./gradlew clean testDebugUnitTest assembleDebug --stacktrace
```

Для release-сборки:

```bash
./gradlew clean testReleaseUnitTest assembleRelease --stacktrace
```

Release APK будет в `app/build/outputs/apk/release/`.

## Что проверено в проекте

- Android manifest и launcher icon присутствуют.
- Hilt/KSP, Room и Jetpack Compose подключены.
- Room хранит выбранный `PerformanceMode`.
- Системные показатели читаются через публичные Android API.
- Unit-тесты `CapabilityChecker` не требуют root.
- CI использует зафиксированный Gradle Wrapper вместо генерации wrapper на лету.

## Ограничения

Обычное Android-приложение не получает произвольный доступ к CPU governor, secure settings и системному управлению частотой обновления. Приложение не заявляет выполнение таких действий без соответствующих полномочий.
